﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            surveyorComboBox.Items.Add("BIRMINGHAMNT");
            surveyorComboBox.Items.Add("BRINKCD");
            surveyorComboBox.Items.Add("HASHMIMS");
            surveyorComboBox.Items.Add("JAMESJR");
            surveyorComboBox.Items.Add("JANIKEJ");
            surveyorComboBox.Items.Add("JONESB7");
            surveyorComboBox.Items.Add("KELLSR");
            surveyorComboBox.Items.Add("SANDSPD");
            surveyorComboBox.Items.Add("SHOTTERAJ");
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void systemTypeLabel_Click(object sender, EventArgs e)
        {

        }

        private void pcNameLabel_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void supportGroupBoxToolTip_Popup(object sender, PopupEventArgs e)
        {

        }

        private void chooseDBButton_Click(object sender, EventArgs e)
        {
            OpenFileDialog ofd = new OpenFileDialog();
            String filePath = "";
            if (ofd.ShowDialog(this) == DialogResult.OK)
            {
                filePath = ofd.InitialDirectory + ofd.FileName;
            }
            
        }

        private void surveyorComboBox_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }
    }
}
