﻿namespace $safeprojectname$
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.chooseDBgroupBox = new System.Windows.Forms.GroupBox();
            this.chooseDBButton = new System.Windows.Forms.Button();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.assignedProjectTextBox = new System.Windows.Forms.TextBox();
            this.assignedProjectLabel = new System.Windows.Forms.Label();
            this.assignButton = new System.Windows.Forms.Button();
            this.snEnterButton = new System.Windows.Forms.Button();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.snLabel = new System.Windows.Forms.Label();
            this.pcNameLabel = new System.Windows.Forms.Label();
            this.buildingLabel = new System.Windows.Forms.Label();
            this.floorLabel = new System.Windows.Forms.Label();
            this.roomLabel = new System.Windows.Forms.Label();
            this.monitorSizeLabel = new System.Windows.Forms.Label();
            this.systemTypeLabel = new System.Windows.Forms.Label();
            this.fieldLabelPanel = new System.Windows.Forms.Panel();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.textBox4 = new System.Windows.Forms.TextBox();
            this.textBox5 = new System.Windows.Forms.TextBox();
            this.textBox6 = new System.Windows.Forms.TextBox();
            this.textBox7 = new System.Windows.Forms.TextBox();
            this.textBox8 = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.specialNotesTextBox = new System.Windows.Forms.TextBox();
            this.locationNotesTextBox = new System.Windows.Forms.TextBox();
            this.specialNotesLabel = new System.Windows.Forms.Label();
            this.locationNotesLabel = new System.Windows.Forms.Label();
            this.notesGroupBox = new System.Windows.Forms.GroupBox();
            this.updateButton = new System.Windows.Forms.Button();
            this.createProjectButton = new System.Windows.Forms.Button();
            this.dispositionBox = new System.Windows.Forms.GroupBox();
            this.label1 = new System.Windows.Forms.Label();
            this.surveyorComboBox = new System.Windows.Forms.ComboBox();
            this.dispositionLabel = new System.Windows.Forms.Label();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.dateTimePicker = new System.Windows.Forms.DateTimePicker();
            this.dateLabel = new System.Windows.Forms.Label();
            this.chooseDBgroupBox.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.fieldLabelPanel.SuspendLayout();
            this.panel1.SuspendLayout();
            this.notesGroupBox.SuspendLayout();
            this.dispositionBox.SuspendLayout();
            this.SuspendLayout();
            // 
            // chooseDBgroupBox
            // 
            this.chooseDBgroupBox.Controls.Add(this.chooseDBButton);
            this.chooseDBgroupBox.Controls.Add(this.textBox1);
            this.chooseDBgroupBox.Location = new System.Drawing.Point(13, 13);
            this.chooseDBgroupBox.Name = "chooseDBgroupBox";
            this.chooseDBgroupBox.Size = new System.Drawing.Size(261, 53);
            this.chooseDBgroupBox.TabIndex = 0;
            this.chooseDBgroupBox.TabStop = false;
            this.chooseDBgroupBox.Text = "CURRENT DATABASE";
            // 
            // chooseDBButton
            // 
            this.chooseDBButton.Location = new System.Drawing.Point(169, 19);
            this.chooseDBButton.Name = "chooseDBButton";
            this.chooseDBButton.Size = new System.Drawing.Size(75, 20);
            this.chooseDBButton.TabIndex = 2;
            this.chooseDBButton.Text = "Choose...";
            this.chooseDBButton.UseVisualStyleBackColor = true;
            this.chooseDBButton.Click += new System.EventHandler(this.chooseDBButton_Click);
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(26, 19);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(137, 20);
            this.textBox1.TabIndex = 1;
            this.textBox1.WordWrap = false;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.createProjectButton);
            this.groupBox1.Controls.Add(this.assignedProjectTextBox);
            this.groupBox1.Controls.Add(this.assignedProjectLabel);
            this.groupBox1.Controls.Add(this.assignButton);
            this.groupBox1.Controls.Add(this.snEnterButton);
            this.groupBox1.Controls.Add(this.textBox2);
            this.groupBox1.Controls.Add(this.snLabel);
            this.groupBox1.Location = new System.Drawing.Point(13, 72);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(262, 140);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "SURVEY";
            // 
            // assignedProjectTextBox
            // 
            this.assignedProjectTextBox.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
            this.assignedProjectTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.assignedProjectTextBox.Location = new System.Drawing.Point(126, 61);
            this.assignedProjectTextBox.Name = "assignedProjectTextBox";
            this.assignedProjectTextBox.ReadOnly = true;
            this.assignedProjectTextBox.Size = new System.Drawing.Size(75, 22);
            this.assignedProjectTextBox.TabIndex = 16;
            // 
            // assignedProjectLabel
            // 
            this.assignedProjectLabel.AutoSize = true;
            this.assignedProjectLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.assignedProjectLabel.Location = new System.Drawing.Point(7, 64);
            this.assignedProjectLabel.Name = "assignedProjectLabel";
            this.assignedProjectLabel.Size = new System.Drawing.Size(113, 16);
            this.assignedProjectLabel.TabIndex = 15;
            this.assignedProjectLabel.Text = "Assigned Project:";
            // 
            // assignButton
            // 
            this.assignButton.Location = new System.Drawing.Point(127, 100);
            this.assignButton.Name = "assignButton";
            this.assignButton.Size = new System.Drawing.Size(99, 23);
            this.assignButton.TabIndex = 11;
            this.assignButton.Text = "Assign...";
            this.assignButton.UseVisualStyleBackColor = true;
            // 
            // snEnterButton
            // 
            this.snEnterButton.Location = new System.Drawing.Point(169, 26);
            this.snEnterButton.Name = "snEnterButton";
            this.snEnterButton.Size = new System.Drawing.Size(75, 20);
            this.snEnterButton.TabIndex = 8;
            this.snEnterButton.Text = "Enter";
            this.snEnterButton.UseVisualStyleBackColor = true;
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(39, 26);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(125, 20);
            this.textBox2.TabIndex = 7;
            this.textBox2.WordWrap = false;
            // 
            // snLabel
            // 
            this.snLabel.AutoSize = true;
            this.snLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.snLabel.Location = new System.Drawing.Point(8, 27);
            this.snLabel.Name = "snLabel";
            this.snLabel.Size = new System.Drawing.Size(30, 16);
            this.snLabel.TabIndex = 0;
            this.snLabel.Text = "SN:";
            this.snLabel.Click += new System.EventHandler(this.label1_Click);
            // 
            // pcNameLabel
            // 
            this.pcNameLabel.AutoSize = true;
            this.pcNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.pcNameLabel.Location = new System.Drawing.Point(4, 7);
            this.pcNameLabel.Name = "pcNameLabel";
            this.pcNameLabel.Size = new System.Drawing.Size(69, 16);
            this.pcNameLabel.TabIndex = 1;
            this.pcNameLabel.Text = "PC Name:";
            this.pcNameLabel.Click += new System.EventHandler(this.pcNameLabel_Click);
            // 
            // buildingLabel
            // 
            this.buildingLabel.AutoSize = true;
            this.buildingLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buildingLabel.Location = new System.Drawing.Point(3, 63);
            this.buildingLabel.Name = "buildingLabel";
            this.buildingLabel.Size = new System.Drawing.Size(59, 16);
            this.buildingLabel.TabIndex = 2;
            this.buildingLabel.Text = "Building:";
            this.buildingLabel.Click += new System.EventHandler(this.label1_Click_1);
            // 
            // floorLabel
            // 
            this.floorLabel.AutoSize = true;
            this.floorLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.floorLabel.Location = new System.Drawing.Point(4, 89);
            this.floorLabel.Name = "floorLabel";
            this.floorLabel.Size = new System.Drawing.Size(42, 16);
            this.floorLabel.TabIndex = 3;
            this.floorLabel.Text = "Floor:";
            // 
            // roomLabel
            // 
            this.roomLabel.AutoSize = true;
            this.roomLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.roomLabel.Location = new System.Drawing.Point(3, 114);
            this.roomLabel.Name = "roomLabel";
            this.roomLabel.Size = new System.Drawing.Size(48, 16);
            this.roomLabel.TabIndex = 4;
            this.roomLabel.Text = "Room:";
            // 
            // monitorSizeLabel
            // 
            this.monitorSizeLabel.AutoSize = true;
            this.monitorSizeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.monitorSizeLabel.Location = new System.Drawing.Point(3, 139);
            this.monitorSizeLabel.Name = "monitorSizeLabel";
            this.monitorSizeLabel.Size = new System.Drawing.Size(69, 16);
            this.monitorSizeLabel.TabIndex = 5;
            this.monitorSizeLabel.Text = "Mon. Size:";
            // 
            // systemTypeLabel
            // 
            this.systemTypeLabel.AutoSize = true;
            this.systemTypeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.systemTypeLabel.Location = new System.Drawing.Point(4, 34);
            this.systemTypeLabel.Name = "systemTypeLabel";
            this.systemTypeLabel.Size = new System.Drawing.Size(63, 16);
            this.systemTypeLabel.TabIndex = 6;
            this.systemTypeLabel.Text = "Sprt. Grp:";
            this.systemTypeLabel.Click += new System.EventHandler(this.systemTypeLabel_Click);
            // 
            // fieldLabelPanel
            // 
            this.fieldLabelPanel.Controls.Add(this.pcNameLabel);
            this.fieldLabelPanel.Controls.Add(this.floorLabel);
            this.fieldLabelPanel.Controls.Add(this.roomLabel);
            this.fieldLabelPanel.Controls.Add(this.systemTypeLabel);
            this.fieldLabelPanel.Controls.Add(this.buildingLabel);
            this.fieldLabelPanel.Controls.Add(this.monitorSizeLabel);
            this.fieldLabelPanel.Location = new System.Drawing.Point(13, 218);
            this.fieldLabelPanel.Name = "fieldLabelPanel";
            this.fieldLabelPanel.Size = new System.Drawing.Size(96, 173);
            this.fieldLabelPanel.TabIndex = 7;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(3, 7);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(147, 20);
            this.textBox3.TabIndex = 8;
            this.textBox3.WordWrap = false;
            // 
            // textBox4
            // 
            this.textBox4.Location = new System.Drawing.Point(3, 34);
            this.textBox4.Name = "textBox4";
            this.textBox4.Size = new System.Drawing.Size(147, 20);
            this.textBox4.TabIndex = 9;
            this.textBox4.WordWrap = false;
            // 
            // textBox5
            // 
            this.textBox5.Location = new System.Drawing.Point(3, 59);
            this.textBox5.Name = "textBox5";
            this.textBox5.Size = new System.Drawing.Size(147, 20);
            this.textBox5.TabIndex = 10;
            this.textBox5.WordWrap = false;
            // 
            // textBox6
            // 
            this.textBox6.Location = new System.Drawing.Point(3, 85);
            this.textBox6.Name = "textBox6";
            this.textBox6.Size = new System.Drawing.Size(147, 20);
            this.textBox6.TabIndex = 11;
            this.textBox6.WordWrap = false;
            // 
            // textBox7
            // 
            this.textBox7.Location = new System.Drawing.Point(3, 113);
            this.textBox7.Name = "textBox7";
            this.textBox7.Size = new System.Drawing.Size(147, 20);
            this.textBox7.TabIndex = 12;
            this.textBox7.WordWrap = false;
            // 
            // textBox8
            // 
            this.textBox8.Location = new System.Drawing.Point(3, 139);
            this.textBox8.Name = "textBox8";
            this.textBox8.Size = new System.Drawing.Size(147, 20);
            this.textBox8.TabIndex = 13;
            this.textBox8.WordWrap = false;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.textBox3);
            this.panel1.Controls.Add(this.textBox8);
            this.panel1.Controls.Add(this.textBox4);
            this.panel1.Controls.Add(this.textBox7);
            this.panel1.Controls.Add(this.textBox5);
            this.panel1.Controls.Add(this.textBox6);
            this.panel1.Location = new System.Drawing.Point(115, 218);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(164, 173);
            this.panel1.TabIndex = 14;
            // 
            // specialNotesTextBox
            // 
            this.specialNotesTextBox.Location = new System.Drawing.Point(15, 40);
            this.specialNotesTextBox.Multiline = true;
            this.specialNotesTextBox.Name = "specialNotesTextBox";
            this.specialNotesTextBox.Size = new System.Drawing.Size(278, 40);
            this.specialNotesTextBox.TabIndex = 15;
            // 
            // locationNotesTextBox
            // 
            this.locationNotesTextBox.Location = new System.Drawing.Point(15, 101);
            this.locationNotesTextBox.Multiline = true;
            this.locationNotesTextBox.Name = "locationNotesTextBox";
            this.locationNotesTextBox.Size = new System.Drawing.Size(278, 41);
            this.locationNotesTextBox.TabIndex = 16;
            // 
            // specialNotesLabel
            // 
            this.specialNotesLabel.AutoSize = true;
            this.specialNotesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.specialNotesLabel.Location = new System.Drawing.Point(12, 21);
            this.specialNotesLabel.Name = "specialNotesLabel";
            this.specialNotesLabel.Size = new System.Drawing.Size(96, 16);
            this.specialNotesLabel.TabIndex = 17;
            this.specialNotesLabel.Text = "Special Notes:";
            // 
            // locationNotesLabel
            // 
            this.locationNotesLabel.AutoSize = true;
            this.locationNotesLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.locationNotesLabel.Location = new System.Drawing.Point(12, 83);
            this.locationNotesLabel.Name = "locationNotesLabel";
            this.locationNotesLabel.Size = new System.Drawing.Size(101, 16);
            this.locationNotesLabel.TabIndex = 18;
            this.locationNotesLabel.Text = "Location Notes:";
            // 
            // notesGroupBox
            // 
            this.notesGroupBox.Controls.Add(this.specialNotesLabel);
            this.notesGroupBox.Controls.Add(this.locationNotesLabel);
            this.notesGroupBox.Controls.Add(this.specialNotesTextBox);
            this.notesGroupBox.Controls.Add(this.locationNotesTextBox);
            this.notesGroupBox.Location = new System.Drawing.Point(296, 13);
            this.notesGroupBox.Name = "notesGroupBox";
            this.notesGroupBox.Size = new System.Drawing.Size(309, 163);
            this.notesGroupBox.TabIndex = 19;
            this.notesGroupBox.TabStop = false;
            this.notesGroupBox.Text = "NOTES";
            // 
            // updateButton
            // 
            this.updateButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.updateButton.Location = new System.Drawing.Point(296, 337);
            this.updateButton.Name = "updateButton";
            this.updateButton.Size = new System.Drawing.Size(153, 54);
            this.updateButton.TabIndex = 20;
            this.updateButton.Text = "Update";
            this.updateButton.UseVisualStyleBackColor = true;
            // 
            // createProjectButton
            // 
            this.createProjectButton.Location = new System.Drawing.Point(11, 100);
            this.createProjectButton.Name = "createProjectButton";
            this.createProjectButton.Size = new System.Drawing.Size(109, 23);
            this.createProjectButton.TabIndex = 17;
            this.createProjectButton.Text = "Create Project...";
            this.createProjectButton.UseVisualStyleBackColor = true;
            // 
            // dispositionBox
            // 
            this.dispositionBox.Controls.Add(this.dateLabel);
            this.dispositionBox.Controls.Add(this.dateTimePicker);
            this.dispositionBox.Controls.Add(this.comboBox1);
            this.dispositionBox.Controls.Add(this.dispositionLabel);
            this.dispositionBox.Controls.Add(this.surveyorComboBox);
            this.dispositionBox.Controls.Add(this.label1);
            this.dispositionBox.Location = new System.Drawing.Point(296, 200);
            this.dispositionBox.Name = "dispositionBox";
            this.dispositionBox.Size = new System.Drawing.Size(309, 123);
            this.dispositionBox.TabIndex = 21;
            this.dispositionBox.TabStop = false;
            this.dispositionBox.Text = "DISPOSITION";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.label1.Location = new System.Drawing.Point(12, 26);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(65, 16);
            this.label1.TabIndex = 0;
            this.label1.Text = "Surveyor:";
            // 
            // surveyorComboBox
            // 
            this.surveyorComboBox.FormattingEnabled = true;
            this.surveyorComboBox.Location = new System.Drawing.Point(90, 21);
            this.surveyorComboBox.Name = "surveyorComboBox";
            this.surveyorComboBox.Size = new System.Drawing.Size(164, 21);
            this.surveyorComboBox.TabIndex = 1;
            this.surveyorComboBox.SelectedIndexChanged += new System.EventHandler(this.surveyorComboBox_SelectedIndexChanged);
            // 
            // dispositionLabel
            // 
            this.dispositionLabel.AutoSize = true;
            this.dispositionLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.dispositionLabel.Location = new System.Drawing.Point(12, 55);
            this.dispositionLabel.Name = "dispositionLabel";
            this.dispositionLabel.Size = new System.Drawing.Size(78, 16);
            this.dispositionLabel.TabIndex = 2;
            this.dispositionLabel.Text = "Disposition:";
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Location = new System.Drawing.Point(90, 54);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(164, 21);
            this.comboBox1.TabIndex = 3;
            // 
            // dateTimePicker
            // 
            this.dateTimePicker.Format = System.Windows.Forms.DateTimePickerFormat.Custom;
            this.dateTimePicker.Location = new System.Drawing.Point(90, 86);
            this.dateTimePicker.Name = "dateTimePicker";
            this.dateTimePicker.Size = new System.Drawing.Size(164, 20);
            this.dateTimePicker.TabIndex = 4;
            // 
            // dateLabel
            // 
            this.dateLabel.AutoSize = true;
            this.dateLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F);
            this.dateLabel.Location = new System.Drawing.Point(12, 87);
            this.dateLabel.Name = "dateLabel";
            this.dateLabel.Size = new System.Drawing.Size(40, 16);
            this.dateLabel.TabIndex = 5;
            this.dateLabel.Text = "Date:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(634, 431);
            this.Controls.Add(this.dispositionBox);
            this.Controls.Add(this.updateButton);
            this.Controls.Add(this.notesGroupBox);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.fieldLabelPanel);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.chooseDBgroupBox);
            this.Name = "Form1";
            this.Text = "SURVEY";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.chooseDBgroupBox.ResumeLayout(false);
            this.chooseDBgroupBox.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.fieldLabelPanel.ResumeLayout(false);
            this.fieldLabelPanel.PerformLayout();
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.notesGroupBox.ResumeLayout(false);
            this.notesGroupBox.PerformLayout();
            this.dispositionBox.ResumeLayout(false);
            this.dispositionBox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox chooseDBgroupBox;
        private System.Windows.Forms.Button chooseDBButton;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label snLabel;
        private System.Windows.Forms.Label buildingLabel;
        private System.Windows.Forms.Label pcNameLabel;
        private System.Windows.Forms.Label systemTypeLabel;
        private System.Windows.Forms.Label monitorSizeLabel;
        private System.Windows.Forms.Label roomLabel;
        private System.Windows.Forms.Label floorLabel;
        private System.Windows.Forms.Button snEnterButton;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.Panel fieldLabelPanel;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.TextBox textBox4;
        private System.Windows.Forms.TextBox textBox5;
        private System.Windows.Forms.TextBox textBox6;
        private System.Windows.Forms.TextBox textBox7;
        private System.Windows.Forms.TextBox textBox8;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button assignButton;
        private System.Windows.Forms.TextBox assignedProjectTextBox;
        private System.Windows.Forms.Label assignedProjectLabel;
        private System.Windows.Forms.TextBox specialNotesTextBox;
        private System.Windows.Forms.TextBox locationNotesTextBox;
        private System.Windows.Forms.Label specialNotesLabel;
        private System.Windows.Forms.Label locationNotesLabel;
        private System.Windows.Forms.GroupBox notesGroupBox;
        private System.Windows.Forms.Button updateButton;
        private System.Windows.Forms.Button createProjectButton;
        private System.Windows.Forms.GroupBox dispositionBox;
        private System.Windows.Forms.ComboBox surveyorComboBox;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.DateTimePicker dateTimePicker;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label dispositionLabel;
        private System.Windows.Forms.Label dateLabel;
    }
}

